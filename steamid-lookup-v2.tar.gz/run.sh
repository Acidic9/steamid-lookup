#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/steamid-lookup-v2.exe" -importPath steamid-lookup-v2 -srcPath "$SCRIPTPATH/src" -runMode prod
